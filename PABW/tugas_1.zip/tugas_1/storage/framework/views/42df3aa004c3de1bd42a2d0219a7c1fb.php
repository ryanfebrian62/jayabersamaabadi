<!DOCTYPE html>
<html>
    <head>
        <title>Daftar Fakultas</title>
        <style>
            table{
                border-collapse: collapse;
                margin: 20px 0;
            }
            table, th, td {
                border: 1px solid black;
            }
            th {
                font-weight: bold;
                background-color: #f2f2f2;
                text-align: center;
            }
            th, td {
                padding: 8px 15px;
            }
        </style>
    </head>
    <body>
        <h2>Daftar Fakultas - Telkom University</h2>
        <table>
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Nama Fakultas</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $fakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($f['Kode']); ?></td>
                    <td><?php echo e($f['nama_fakultas']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </body>
</html><?php /**PATH C:\SEMESTER 3\PABW\PABW\PABW\resources\views/fakultas.blade.php ENDPATH**/ ?>